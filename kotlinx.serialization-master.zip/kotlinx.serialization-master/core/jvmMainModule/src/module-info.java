module kotlinx.serialization.core {
    requires transitive kotlin.stdlib;

    exports kotlinx.serialization;
    exports kotlinx.serialization.builtins;
    exports kotlinx.serialization.descriptors;
    exports kotlinx.serialization.encoding;
    exports kotlinx.serialization.internal;
    exports kotlinx.serialization.modules;
}
