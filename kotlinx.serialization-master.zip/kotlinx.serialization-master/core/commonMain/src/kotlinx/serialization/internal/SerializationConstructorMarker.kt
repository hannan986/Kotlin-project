/*
 * Copyright 2017-2020 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license.
 */

package kotlinx.serialization.internal

@Suppress("UNUSED")
@Deprecated("Inserted into generated code and should not be used directly", level = DeprecationLevel.HIDDEN)
public class SerializationConstructorMarker private constructor()
