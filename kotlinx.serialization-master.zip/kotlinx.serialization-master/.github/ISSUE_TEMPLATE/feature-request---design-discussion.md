---
name: Feature request / design discussion
about: Suggest an idea for this project
title: ''
labels: feature
assignees: ''

---

**What is your use-case and why do you need this feature?**

**Describe the solution you'd like**
