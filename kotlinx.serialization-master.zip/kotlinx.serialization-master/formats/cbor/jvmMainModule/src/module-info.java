module kotlinx.serialization.cbor {
    requires transitive kotlin.stdlib;
    requires transitive kotlinx.serialization.core;

    exports kotlinx.serialization.cbor;
}
