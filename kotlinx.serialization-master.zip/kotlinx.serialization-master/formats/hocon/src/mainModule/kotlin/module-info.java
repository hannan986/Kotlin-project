module kotlinx.serialization.hocon {
    requires transitive kotlin.stdlib;
    requires transitive kotlinx.serialization.core;
    requires transitive kotlin.stdlib.jdk8;
    requires transitive typesafe.config;

    exports kotlinx.serialization.hocon;
}
