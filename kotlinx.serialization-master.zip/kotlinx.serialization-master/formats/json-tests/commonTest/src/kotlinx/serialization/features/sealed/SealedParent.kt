package kotlinx.serialization.features.sealed

import kotlinx.serialization.Serializable

@Serializable
sealed class SealedParent(val i: Int)
