The documentation has been moved to the [value-classes.md](value-classes.md) page.
